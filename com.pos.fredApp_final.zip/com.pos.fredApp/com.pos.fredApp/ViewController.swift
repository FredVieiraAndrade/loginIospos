//
//  ViewController.swift
//  com.pos.fredApp
//
//  Created by user201570 on 10/20/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtLogin: UITextField!
    @IBOutlet weak var TxtSenha: UITextField!
    @IBOutlet weak var btnEntrar: UIButton!
        
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let acesso = UserDefaults.standard.bool(forKey: "KeyLogin")
        if acesso == true {
            self.performSegue(withIdentifier: "principal", sender: self)
        }
    }

    
    @IBAction func onClickEntrar(_ sender: Any) {
        logIn()
    }
    
    private func logIn() {
        if valida(login: txtLogin.text, senha: TxtSenha.text) == true {
            UserDefaults.standard.set(true, forKey: "KeyLogin")
            let viewController = storyboard?.instantiateViewController(withIdentifier: "PrinciplalViewController")
            navigationController?.pushViewController(viewController!, animated: true)
        }
    }
    private func isLoginValid(login: String) -> Bool {
            if login.count > 0 {
                if isValidEmail(email: login) == true {
                    return true
                } else {
                    return false
                }
            } else {
                return false
            }
        }
     
    private func isSenhaValid(login: String) -> Bool {
        if login.count > 0 {
            return true
        } else {
            return false
        }
    }

    private func valida(login: String?, senha: String?) -> Bool {
        if let login = login, isLoginValid(login: login) {
            if let senha = senha, isSenhaValid(login: senha) {
                return true
            } else {
                self.mensagemAlerta(mensagem: "O campo senha não pode ser vazio!")
                return false
            }
        } else {
            self.mensagemAlerta(mensagem: "O campo login precisa de um email valido!")
            return false
        }
    }
    
    private func isValidEmail(email: String) -> Bool {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with: email)
        
        return result
    }
    
    private func mensagemAlerta(mensagem: String) {
        let alert = UIAlertController(title: "Atenção", message: mensagem, preferredStyle: .alert)
        let ok = UIAlertAction(title: "Ok", style: .default, handler: nil)
        alert.addAction(ok)
        present(alert, animated: true, completion: nil)
        
    }
}

