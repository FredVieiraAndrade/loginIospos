//
//  PrinciplalViewController.swift
//  com.pos.fredApp
//
//  Created by user201570 on 10/20/21.
//

import UIKit

class PrinciplalViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.portrait, andRotateTo: UIInterfaceOrientation.portrait)

        navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(), style: .plain, target: nil, action: nil)
    }
    
    @IBAction func onClickSair(_ sender: Any) {
        UserDefaults.standard.removeObject(forKey: "KeyLogin")
        let principalViewController = storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        self.view.window?.rootViewController = UINavigationController(rootViewController: principalViewController)
        self.view.window?.makeKeyAndVisible()
    }
    
}
